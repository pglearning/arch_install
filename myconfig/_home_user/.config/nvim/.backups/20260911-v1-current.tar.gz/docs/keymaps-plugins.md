# 插件与自定义快捷键

> 本文列出**本配置添加**的键位：自定义核心键位 + 各插件键位。
> 每个键位都标注了定义文件，改键位直接去对应文件改（插件键位就写在插件自己的文件里）。
> 原生默认键位见 `keymaps-native.md`。
> `mapleader` = `空格`，`maplocalleader` = `\`。

## 0. 文件对照

| 文件 | 负责的键位 |
|---|---|
| `lua/keymaps/keymaps.lua` | 核心/Emacs 层（不依赖插件） |
| `lua/config/lazy.lua` | `<localleader>l`、`<localleader>h` |
| `lua/plugins/snacks.lua` | 查找/git/buffer/UI 的 leader 键位、`C-x C-f`、`C-x b`、`M-x` |
| `lua/plugins/blink.lua` | 插入/命令行模式的补全键位 |
| `lua/plugins/lsp.lua` | `<leader>li`、`gd`、`<leader>lc`（后两个 buffer-local） |
| `lua/plugins/neo-tree.lua` | `<leader>e`（树内键位由 neo-tree 默认提供） |
| `lua/plugins/gitsigns.lua` | `<leader>gh*`、`]h`/`[h`（buffer-local） |
| `lua/plugins/conform.lua` | `<leader>lf` |

---

## 1. 自定义核心键位（`lua/keymaps/keymaps.lua`）

### 1.1 Emacs 层

| 键 | 作用 |
|---|---|
| `C-x C-f` | 找文件（snacks picker） |
| `C-x b` | 切换 buffer（snacks picker） |
| `C-x C-s` | 保存 |
| `C-x C-c` | 退出所有窗口（未保存会询问） |
| `C-x h` | 全选（`ggVG`） |
| `C-x k` | 关闭当前 buffer |
| `C-x 2` | 上下分屏 |
| `C-x 3` | 左右分屏 |
| `C-x o` | 切到另一个窗口 |
| `C-x 0` | 关闭当前窗口 |
| `C-x 1` | 关闭其它窗口 |
| `M-x` (`A-x`) | 命令面板（命令补全 + 执行） |
| `C-g` | 取消搜索高亮（keyboard-quit） |

### 1.2 编辑与移动

| 键 | 模式 | 作用 |
|---|---|---|
| `jk` | i | 退出插入模式 |
| `<C-j>` / `<C-k>` | n/v/o | 下/上移动 5 行 |
| `<C-j>` / `<C-k>` | v | 下/上移动选中的代码块（覆盖上面的 5 行跳转） |
| `>` / `<` | v | 缩进/反缩进并保持选中 |
| `<leader>nh` | n/v/o | 取消搜索高亮 |
| `<leader>F` | n/o | 搜索光标下的单词（`/` + `<C-r><C-w>`） |
| `<leader>r` | n/v | 用光标下单词做替换，光标停在 `//` 之间等待输入 |
| `<leader>R` | n/v | 同上，但逐个确认（`gc`） |

### 1.3 文件 / 窗口 / 编译

| 键 | 作用 |
|---|---|
| `<leader>w` / `<leader>q` | 保存 / 关闭当前窗口 |
| `<leader>fn` | 新建文件（垂直分屏，`:vnew ` 可继续输入文件名） |
| `<F5>` | 打开终端分屏（`:split \| terminal ` 可继续输入命令） |
| `<A-f>` | 当前窗口最大化 |
| `<A-=>` | 所有窗口等大 |
| `<A-+>` / `<A-->` | 窗口高度 +3 / -3 |
| `<A-.>` / `<A-,>` | 窗口宽度 +5 / -5 |
| `<leader>mm` | `:make`（调用 make 并填充 quickfix） |
| `<leader>mq` / `<leader>mc` | 打开 / 关闭 quickfix 窗口 |

> `<A-*>` 系列需要终端把 Alt 正确发送给 nvim（你现在用的终端已经支持，因为原来就在用 `<A-f>`）。
> 窗口导航仍用原生 `<C-w>h/j/k/l`，没有自定义。

---

## 2. leader 分组总览（which-key，`lua/plugins/which-key.lua`）

| 前缀 | 分组 | 前缀 | 分组 |
|---|---|---|---|
| `<leader>b` | buffer | `<leader>l` | lsp |
| `<leader>f` | find/file | `<leader>m` | make/quickfix |
| `<leader>g` | git | `<leader>u` | ui |
| `[` / `]` | prev / next | `g` | goto |
| `z` | fold | `<C-x>` | emacs prefix |

按 `<leader>` 稍等片刻即可看到分组面板；`<leader>fk` 可以搜索所有键位。

---

## 3. snacks.nvim（`lua/plugins/snacks.lua`）

### 3.1 打开 picker

| 键 | 作用 |
|---|---|
| `<C-x><C-f>` / `<leader>ff` | 找文件 |
| `<leader>fg` | 全文搜索（grep） |
| `<leader>fw` | 搜索光标下的单词（Emacs 的 occur） |
| `<leader>fb` | buffer 列表 |
| `<leader>fr` | 最近文件 |
| `<leader>fs` | 智能查找（buffer + 最近 + 文件混合） |
| `<leader>fh` / `<leader>fk` / `<leader>fc` | 帮助文档 / 键位 / 命令 |
| `<leader>fd` | 诊断列表 |
| `<leader>gs` / `<leader>gl` / `<leader>gd` | git status / log / diff |
| `<leader>gB` | 在浏览器打开当前文件（非 git 目录会提示而不是报错） |
| `<C-x>b` | 切换 buffer |
| `M-x` (`A-x`) | 命令面板 |

### 3.2 picker 内部键位（snacks 默认，输入框与结果列表通用）

| 键 | 作用 | 键 | 作用 |
|---|---|---|---|
| `<CR>` | 打开选中项 | `<S-CR>` | 先选一个窗口，再在那里打开该项 |
| `<Esc>` / `q` | 关闭 | `<C-c>` | 关闭（插入模式） |
| `<Tab>` / `<S-Tab>` | 下一个 / 上一个并多选 | `<C-a>` | 全选 |
| `<C-j>` `<C-k>` / `<C-n>` `<C-p>` | 列表下 / 上移动 | `j` `k` / `<Up>` `<Down>` | 同上 |
| `<C-d>` `<C-u>` | 列表翻半页 | `<C-f>` `<C-b>` | 预览翻页 |
| `gg` / `G` | 列表首 / 列表尾 | `zt` `zz` `zb` | 结果列表滚到 顶/中/底（仅结果列表窗口） |
| `/` | 在输入框和结果列表之间切换焦点 | `<a-w>` | 在输入/列表/预览窗口间循环 |
| `?` | 显示当前 picker 的帮助 | `<a-d>` | 调试：查看当前项的数据 |
| `<a-f>` | 切换 follow（跟随当前文件） | `<a-h>` / `<a-i>` | 切换显示隐藏文件 / gitignore 文件 |
| `<a-r>` | 切换正则模式（仅输入框） | `<a-m>` / `<a-p>` | 最大化 / 开关预览 |
| `<C-g>` | 输入框：切换 live 模式；结果列表：打印路径 | | |
| `<C-s>` / `<C-v>` / `<C-t>` | 分屏 / 垂直分屏 / 新标签页打开 | `<C-q>` | 把结果送入 quickfix |
| `<C-w>H/J/K/L` | 把 picker 布局改成 左/下/上/右 | `<C-s>`/`<C-v>`/`<C-t>` | 见上（分屏打开） |
| `<C-r><C-w>` | 插入光标下的单词 | `<C-r>%` / `<C-r>#` | 插入文件名 / 备用文件名 |
| `<C-r><C-l>` / `<C-r><C-f>` | 插入当前行 / 光标下的文件名 | `i` | （仅结果列表）回到输入框 |

> 预览窗口单独有：`<Esc>`/`q` 关闭、`i` 回到输入框、`<a-w>` 切换到别的窗口。

### 3.3 其它 snacks 功能

| 键 | 作用 |
|---|---|
| `<leader>bd` / `<leader>bo` | 关闭当前 buffer / 关闭其它 buffer（保持窗口布局） |
| `<leader>un` | 通知历史（错过 `vim.notify` 时回看） |
| `<leader>uz` / `<leader>uZ` | zen 模式 / zoom 模式（专注写代码） |

---

## 4. blink.cmp 补全（`lua/plugins/blink.lua`）

插入模式使用 `super-tab` 预设（Tab 接受补全，VSCode 风格）：

| 键 | 作用 |
|---|---|
| `<Tab>` | 有选中项则接受；片段激活时跳到下一个占位符；否则是普通 Tab |
| `<S-Tab>` | 片段上一个占位符 |
| `<C-space>` | 打开补全菜单 / 打开文档 / 关闭文档 |
| `<C-e>` | 取消补全 |
| `<C-n>` / `<C-p>` / `<Down>` / `<Up>` | 下一个 / 上一个候选 |
| `<C-b>` / `<C-f>` | 文档上滚 / 下滚 |
| `<C-k>` | 显示 / 隐藏函数签名（`signature` 已在配置里开启） |

命令行模式使用同一套预设，另外 `auto_show = true` 表示输入 `:` 时也会自动弹候选。

> 只改了 `documentation.auto_show = true`（默认 false）和 `signature.enabled = true`（默认 false），
> `sources` 顺序为 `path → snippets → buffer → lsp`。

---

## 5. LSP（`lua/plugins/lsp.lua`）

原生 `grn` `gra` `grr` `gri` `grt` `grx` `gO` `K` `i_<C-S>` 已够用（见 `keymaps-native.md` §1.2），本配置只补：

| 键 | 作用域 | 作用 |
|---|---|---|
| `gd` | 仅 LSP 挂载的 buffer | 跳转到定义 |
| `<leader>lc` | 仅 clangd 挂载的 buffer | 在源文件生成函数定义（Generate definition） |
| `<leader>li` | 全局 | 开关内联提示（inlay hints，C/C++ 的参数名提示） |

诊断显示：`update_in_insert`、`virtual_text`、`underline`、`severity_sort`、自定义图标；`]d`/`[d` 跳转（原生）。
`:checkhealth vim.lsp` 可以看到每个 server 的状态。

---

## 6. neo-tree 文件树（`lua/plugins/neo-tree.lua`）

| 键 | 作用 |
|---|---|
| `<leader>e` | 开关文件树 |

树内键位（neo-tree 默认，`?` 可查看完整帮助）：

| 键 | 作用 | 键 | 作用 |
|---|---|---|---|
| `<CR>` / `<2-LeftMouse>` | 打开文件/展开目录 | `<Space>` | 展开/折叠节点 |
| `s` / `S` / `t` | 垂直分屏 / 水平分屏 / 新标签页打开 | `l` | 聚焦预览 |
| `P` | 浮动预览 | `C` / `z` | 关闭节点 / 全部折叠 |
| `H` | 显示/隐藏隐藏文件 | `/` `D` `#` | 模糊查找 / 目录查找 / 模糊排序 |
| `a` / `A` | 新建文件 / 新建目录 | `d` / `r` | 删除 / 重命名 |
| `b` | 重命名文件名部分（不含扩展名） | `i` | 显示文件详情（大小/时间） |
| `y` `x` `p` `<C-r>` | 复制 / 剪切 / 粘贴 / 清空剪贴板 | `c` / `m` | 复制 / 移动 |
| `<bs>` / `.` | 回到上级 / 设为根目录 | `[g` / `]g` | 上一个/下一个 git 改动文件 |
| `oc` `od` `og` `om` `on` `os` `ot` | 按 创建时间/诊断/git/修改时间/名字/大小/类型 排序 | `R` | 刷新 |
| `q` | 关闭文件树 | `<` / `>` | 上一个 / 下一个数据源 |

---

## 7. gitsigns（`lua/plugins/gitsigns.lua`，buffer-local）

| 键 | 作用 |
|---|---|
| `]h` / `[h` | 下一个 / 上一个 hunk（在 diff 模式下自动改用 `]c`/`[c`） |
| `<leader>ghs` / `<leader>ghr` | 暂存 / 撤销当前 hunk（visual 模式下作用于选中行） |
| `<leader>ghS` / `<leader>ghR` | 暂存 / 撤销整个文件 |
| `<leader>ghp` | 浮动预览当前 hunk |
| `<leader>ghb` | 当前行的 blame（作者/时间/提交信息） |
| `<leader>ghd` / `<leader>ghD` | 与索引 / 与上一次提交对比 |
| `ih` | hunk 文本对象（`dih` 撤销一个 hunk，`vih` 选中） |

---

## 8. conform 格式化（`lua/plugins/conform.lua`）

| 键 | 作用 |
|---|---|
| `<leader>lf` | 格式化当前文件；visual 模式下只格式化选中范围 |

按文件类型使用的格式化器：

| 文件类型 | 格式化器 | 文件类型 | 格式化器 |
|---|---|---|---|
| `c` / `cpp` | `clang-format` | `lua` | `stylua` |
| `sh` / `bash` / `zsh` | `shfmt` | `python` | `ruff_format` |
| `json` / `jsonc` / `yaml` / `markdown` | `prettier` | `cmake` | `cmake-format` |
| `toml` | `taplo` | 其它 | 回退到 LSP 格式化（`lsp_format = "fallback"`） |

保存时自动格式化**默认关闭**；要开启就在该文件里取消注释 `format_on_save`。

---

## 9. treesitter 相关

| 键 / 命令 | 来源 | 作用 |
|---|---|---|
| `za` `zR` `zM` `zc` `zj` `zk` | 原生折叠命令 | 折叠由 treesitter 提供（`foldexpr`），C/Lua/Markdown 等直接可用 |
| `]n` `[n` `]N` `[N` `an` `in` | nvim 0.12 原生 | 语法树节点选择 |
| `:TSInstall <lang>` | nvim-treesitter | 安装 parser（需要 `tree-sitter-cli`） |
| `:TSUpdate` / `:TSUninstall` / `:TSLog` | nvim-treesitter | 更新 / 卸载 / 查看日志 |
| `:TSContext toggle` | treesitter-context | 开关顶部"当前函数/类"上下文条 |
| `:checkhealth nvim-treesitter` | nvim-treesitter | 检查 ABI 与 tree-sitter-cli 版本 |

---

## 10. 常用命令速查

| 命令 | 来源 | 作用 |
|---|---|---|
| `<localleader>l` / `:Lazy` | lazy.nvim | 插件管理界面（`S` 同步、`U` 更新、`C` 检查、`X` 清理） |
| `<localleader>h` / `:checkhealth` | nvim | 健康检查（`vim.lsp`、`nvim-treesitter`、`snacks` 等） |
| `:Mason` | mason | 图形化安装 LSP / 格式化工具 |
| `:MasonInstall <pkg>` / `:MasonUninstall <pkg>` / `:MasonLog` | mason | 安装 / 卸载 / 查看日志 |
| `:LspInstall <server>` / `:LspUninstall` | mason-lspconfig | 按 server 名安装 / 卸载 |
| `:ConformInfo` | conform | 查看当前 buffer 会用哪个格式化器、日志位置 |
| `:Gitsigns <子命令>` | gitsigns | `stage_hunk` `reset_hunk` `preview_hunk` `blame_line` `diffthis` `nav_hunk next` `toggle_current_line_blame` `toggle_word_diff` `setqflist` |
| `:Catppuccin <flavour>` / `:CatppuccinCompile` | catppuccin | 切换配色（latte/frappe/macchiato/mocha）/ 重新编译 |
| `:TSInstall` `:TSUpdate` | nvim-treesitter | 见 §9 |

---

## 11. 自己排查键位

| 做法 | 说明 |
|---|---|
| `<leader>fk` | snacks 的键位搜索器（可按名字/描述过滤，最直观） |
| `:verbose map <C-x>` | 查看某个键被谁映射、定义在哪个文件哪一行 |
| `:map` / `:nmap` / `:vmap` / `:imap` | 列出全部映射（`:map!` 看插入/命令行模式） |
| `:verbose nmap <Space>ff` | 检查 leader 键位的实际绑定与定义位置（`<leader>` 要写成 `<Space>`） |
| `:nmap <C-v><C-x>` | 列出所有 `C-x` 前缀的映射（`<C-v>` 用来输入控制字符） |
| `:Lazy` → `keys` 列 | 查看哪些键位触发了插件的懒加载 |

> 加新键位时的两条原则（本配置遵循）：
> 1. **插件键位写在对应插件文件里**（全局用 lazy 的 `keys = {...}`，跟 buffer 有关的用 `LspAttach`/`on_attach`）；
> 2. **不要占用原生默认键**，nvim 0.12 尤其要注意 `g` 系（`grn/gra/grr/gri/grt/grx/gO/gc/gx`）、
> `]`/`[` 系（`]d [d ]q [q ]l [l ]a [a ]t [t ]b [b ]n [n ]<Space>`）和 `<C-w>` 系。
