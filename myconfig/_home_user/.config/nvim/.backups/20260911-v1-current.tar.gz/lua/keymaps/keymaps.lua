-- Keymaps Setting --
-- 只放"不依赖插件"的全局快捷键; 插件自己的快捷键写在 lua/plugins/对应插件.lua 中
vim.g.mapleader = " "                   -- set leader space
vim.g.maplocalleader = "\\"

local keymap = vim.keymap.set

---- Insert ----
keymap("i", "jk", "<Esc>", { desc = "Escape insert mode" })

---- Emacs style prefix: C-x ----
-- 与 Emacs 对齐: C-x C-s 保存, C-x C-c 退出, C-x 2/3/o/0/1 窗口, C-x h 全选, C-x k 关闭 buffer
-- 插件相关的 C-x 绑定在插件文件中: C-x C-f 找文件 / C-x b 切 buffer (snacks)
keymap("n", "<C-x><C-s>", "<cmd>write<CR>", { desc = "Save buffer (C-x C-s)" })
keymap("n", "<C-x><C-c>", "<cmd>confirm qa<CR>", { desc = "Quit all, ask to save (C-x C-c)" })
keymap("n", "<C-x>h", "ggVG", { desc = "Select whole buffer (C-x h)" })
keymap("n", "<C-x>k", "<cmd>bdelete<CR>", { desc = "Kill current buffer (C-x k)" })
keymap("n", "<C-x>2", "<C-w>s", { desc = "Split window below (C-x 2)" })
keymap("n", "<C-x>3", "<C-w>v", { desc = "Split window right (C-x 3)" })
keymap("n", "<C-x>o", "<C-w>w", { desc = "Switch to other window (C-x o)" })
keymap("n", "<C-x>0", "<C-w>c", { desc = "Delete current window (C-x 0)" })
keymap("n", "<C-x>1", "<C-w>o", { desc = "Delete other windows (C-x 1)" })

---- Emacs style: cancel ----
keymap("n", "<C-g>", "<cmd>nohlsearch<CR>", { desc = "Cancel search highlight (C-g)" })

---- Cursor ----
-- 'W' 大写单词忽略符号, 'w' 忽略符号; 这里只做整行的快速跳转
keymap({ "n", "v", "o" }, "<C-j>", "5j", { desc = "Move down 5 lines" })
keymap({ "n", "v", "o" }, "<C-k>", "5k", { desc = "Move up 5 lines" })

---- Move code / indent ----
-- Visual 模式下的 <C-j>/<C-k> 覆盖上面的整行跳转, 用于上下移动选中块
keymap("v", "<C-j>", ":m '>+1<CR>gv=gv", { desc = "Move selected lines down" })
keymap("v", "<C-k>", ":m '<-2<CR>gv=gv", { desc = "Move selected lines up" })
keymap("v", ">", ">gv", { desc = "Indent and keep selection" })
keymap("v", "<", "<gv", { desc = "Outdent and keep selection" })

---- Highlight / search ----
keymap({ "n", "v", "o" }, "<leader>nh", "<cmd>nohlsearch<CR>", { desc = "No highlight" })
keymap({ "n", "o" }, "<leader>F", "/<C-r><C-w><CR>", { desc = "Search word under cursor" })

---- Replace (Emacs M-%) ----
-- 光标停在 // 之间, 直接输入替换内容即可; I 表示忽略大小写
keymap("n", "<leader>r", ":%s/\\<<C-r><C-w>\\>//gI<Left><Left><Left><Left>", { desc = "Replace word in buffer" })
keymap("v", "<leader>r", ":s/\\<<C-r><C-w>\\>//gI<Left><Left><Left><Left>", { desc = "Replace word in selection" })
keymap("n", "<leader>R", ":%s/\\<<C-r><C-w>\\>//gcI<Left><Left><Left><Left>", { desc = "Replace word in buffer, confirm each" })
keymap("v", "<leader>R", ":s/\\<<C-r><C-w>\\>//gcI<Left><Left><Left><Left>", { desc = "Replace word in selection, confirm each" })

---- File ----
keymap({ "n", "v", "o" }, "<leader>w", "<cmd>write<CR>", { desc = "Save file" })
keymap({ "n", "v", "o" }, "<leader>q", "<cmd>quit<CR>", { desc = "Quit window" })
keymap("n", "<leader>fn", ":vnew ", { desc = "New file in vertical split" })
keymap("n", "<F5>", ":split | terminal ", { desc = "Open terminal in horizontal split" })

---- Window ----
-- 更多窗口操作使用 nvim 内建: <C-w>h/j/k/l 切换, <C-w>+/- 高度, <C-w></> 宽度
keymap({ "n", "v", "o" }, "<A-f>", "<C-w>_<C-w>|", { desc = "Maximize current window" })
keymap({ "n", "v", "o" }, "<A-=>", "<C-w>=", { desc = "Equalize window size" })
keymap({ "n", "v", "o" }, "<A-+>", "<cmd>resize +3<CR>", { desc = "Increase window height" })
keymap({ "n", "v", "o" }, "<A-->", "<cmd>resize -3<CR>", { desc = "Decrease window height" })
keymap({ "n", "v", "o" }, "<A-.>", "<cmd>vertical resize +5<CR>", { desc = "Increase window width" })
keymap({ "n", "v", "o" }, "<A-,>", "<cmd>vertical resize -5<CR>", { desc = "Decrease window width" })

---- Make / quickfix (C/C++ 日常) ----
-- 内建 ]q / [q 可以在 quickfix 中跳转, :make 默认调用 make 并解析编译错误
keymap("n", "<leader>mm", "<cmd>make<CR>", { desc = "Run make, fill quickfix" })
keymap("n", "<leader>mq", "<cmd>copen<CR>", { desc = "Open quickfix list" })
keymap("n", "<leader>mc", "<cmd>cclose<CR>", { desc = "Close quickfix list" })
