-- snacks 提供的动画(scroll/indent/dim), 必须在 setup 之前设置
vim.g.snacks_animate = false

return {
    "folke/snacks.nvim",
    priority = 1000,
    lazy = false,
    keys = {
        ---- Emacs style prefix: C-x / M-x ----
        { "<C-x><C-f>", function() Snacks.picker.files() end, desc = "Find file (C-x C-f)" },
        { "<C-x>b", function() Snacks.picker.buffers() end, desc = "Switch buffer (C-x b)" },
        { "<A-x>", function() Snacks.picker.commands() end, desc = "Run command (M-x)" },

        ---- find / file ----
        { "<leader>ff", function() Snacks.picker.files() end, desc = "Find files" },
        { "<leader>fg", function() Snacks.picker.grep() end, desc = "Grep" },
        { "<leader>fw", function() Snacks.picker.grep_word() end, desc = "Grep word under cursor" },
        { "<leader>fb", function() Snacks.picker.buffers() end, desc = "Buffers" },
        { "<leader>fr", function() Snacks.picker.recent() end, desc = "Recent files" },
        { "<leader>fs", function() Snacks.picker.smart() end, desc = "Smart find" },
        { "<leader>fh", function() Snacks.picker.help() end, desc = "Help pages" },
        { "<leader>fk", function() Snacks.picker.keymaps() end, desc = "Keymaps" },
        { "<leader>fc", function() Snacks.picker.commands() end, desc = "Commands" },
        { "<leader>fd", function() Snacks.picker.diagnostics() end, desc = "Diagnostics" },

        ---- git (hunk 操作见 gitsigns.lua) ----
        { "<leader>gs", function() Snacks.picker.git_status() end, desc = "Git status" },
        { "<leader>gl", function() Snacks.picker.git_log() end, desc = "Git log" },
        { "<leader>gd", function() Snacks.picker.git_diff() end, desc = "Git diff" },
        { "<leader>gB", function()
            -- snacks 的 gitbrowse 在非 git 目录会直接抛错, 这里先用 get_root 判断
            if Snacks.git.get_root() then
                Snacks.gitbrowse()
            else
                vim.notify("gitbrowse: not inside a git repository", vim.log.levels.WARN)
            end
        end, desc = "Open current file in browser" },

        ---- buffer / ui ----
        { "<leader>bd", function() Snacks.bufdelete() end, desc = "Delete buffer, keep layout" },
        { "<leader>bo", function() Snacks.bufdelete.other() end, desc = "Delete other buffers" },
        { "<leader>un", function() Snacks.notifier.show_history() end, desc = "Notification history" },
        { "<leader>uz", function() Snacks.zen() end, desc = "Toggle zen mode" },
        { "<leader>uZ", function() Snacks.zen.zoom() end, desc = "Toggle zoom" },
    },
    opts = {
        -- 下面这些模块默认是关闭的, 必须显式 enabled = true 才会生效 --
        bigfile = { enabled = true },       -- 大文件优化 (notify / size / line_length / setup)
        dashboard = { enabled = true },     -- 启动面板 (width / row / col / pane_gap / preset / sections)
        indent = { enabled = true },        -- 缩进线 (indent / scope / chunk / animate / filter)
        input = { enabled = true },         -- vim.ui.input 美化 (icon / icon_pos / prompt_pos / win / expand)
        picker = { enabled = true },        -- 选择器 (layout / matcher / sort / preview / win / icons / sources)
        notifier = { enabled = true },      -- vim.notify 美化 (timeout / width / height / style / icons / sort)
        quickfile = { enabled = true },     -- 打开大文件时先渲染 (exclude)
        scope = { enabled = true },         -- 作用域跳转与文本对象 ii / ai, [i / ]i (min_size / cursor / edge)
        scroll = { enabled = true },        -- 平滑滚动 (animate / animate_repeat / filter)
        statuscolumn = { enabled = true },  -- 状态列 (left / right / folds / git / refresh)
        words = { enabled = true },         -- LSP 引用高亮与跳转 (debounce / modes / notify_jump / jumplist)

        -- explorer = { enabled = false },  -- snacks 自带文件树; 这里用 neo-tree, 若想更精简可改 true 并删掉 neo-tree

        -- 默认就可用(无需 enabled)的模块: animate / bufdelete / git / gitbrowse / notify / terminal / toggle / util / win / zen
        styles = {
            notification = {
                wo = { wrap = true },       -- 通知内容自动换行
            },
        },
    },
}
