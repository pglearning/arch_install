return {
    "catppuccin/nvim",
    name = "catppuccin",
    opts = {
        -- 官方选项较多, 完整列表见 :help catppuccin-options
        flavour = "mocha",          -- 官方默认 "mocha": latte | frappe | macchiato | mocha
        term_colors = true,         -- 官方默认 false, 同时设置终端 16 色
    },
    config = function(_, opts)
        require("catppuccin").setup(opts)
        vim.cmd.colorscheme("catppuccin")
    end,
}
