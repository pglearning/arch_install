return {
    -- Mason: LSP server 与外部工具(格式化/检查)的安装器 --
    {
        "mason-org/mason.nvim",
        -- 注意: mason.nvim 本身没有 ensure_installed 选项, server 的自动安装由下面的
        -- mason-lspconfig 负责, formatter/linter 由后面 config 里的 :MasonInstall 负责
        opts = {
            -- 官方默认值, 列出供参考:
            -- install_root_dir = vim.fn.stdpath("data") .. "/mason"
            -- PATH = "prepend"                            -- mason 的 bin 加入 PATH 的方式
            -- max_concurrent_installers = 4
            -- registries = { "github:mason-org/mason-registry" }
            -- ui = { border = nil, backdrop = 60, width = 0.8, height = 0.9, icons = {...} }
        },
    },

    -- Mason 与 nvim 0.11+ 原生 vim.lsp.config / vim.lsp.enable 的桥接 --
    {
        "mason-org/mason-lspconfig.nvim",
        dependencies = { "mason-org/mason.nvim", "neovim/nvim-lspconfig" },
        opts = {
            -- 该版本官方配置项只有两个: ensure_installed / automatic_enable
            -- 这里写的是 nvim-lspconfig 的 server 名(不是 mason 包名), 装完会自动 enable
            ensure_installed = {
                "lua_ls",           -- lua
                "bashls",           -- bash / sh / zsh
                "ruff",             -- python: lint + format
                "ty",               -- python: 类型检查
                "jsonls",           -- json / jsonc
                "yamlls",           -- yaml
                "taplo",            -- toml
                "neocmake",         -- cmake
                "cssls",            -- css / scss / less
                -- 如需其它语言, 取消注释即可(会自动下载对应 server):
                -- "vtsls", "tailwindcss", "gopls", "marksman",
            },
            automatic_enable = true,    -- 官方默认值: mason 安装的 server 自动 vim.lsp.enable()
        },
        config = function(_, opts)
            require("mason-lspconfig").setup(opts)

            -- formatter / linter 不属于 LSP, 不能用 ensure_installed, 这里用官方 API 补装
            -- 不要重复列出 ruff / neocmakelsp, 它们已经由上面的 server 安装
            local tools = {
                "stylua",           -- lua
                "shfmt",            -- bash
                "shellcheck",       -- bash
                "cmakelang",        -- cmake-format / cmake-lint
                "prettier",         -- json / yaml / markdown
            }
            local registry = require("mason-registry")
            local missing = vim.tbl_filter(function(name)
                return not registry.is_installed(name)
            end, tools)
            if #missing > 0 then
                vim.cmd("MasonInstall " .. table.concat(missing, " "))
            end
        end,
    },

    -- LSP 本体: nvim 0.11+ 官方写法是用 vim.lsp.config() 配置, vim.lsp.enable() 启用 --
    {
        "neovim/nvim-lspconfig",
        dependencies = { "saghen/blink.cmp" },
        config = function()
            -- 用 "*" 一次性给所有 server 加上 blink.cmp 的补全能力
            -- (* 的配置会和 nvim-lspconfig 里 lsp/<name>.lua 的默认值深合并)
            vim.lsp.config("*", {
                capabilities = require("blink.cmp").get_lsp_capabilities(),
            })

            -- 诊断显示 --
            vim.diagnostic.config({
                update_in_insert = true,
                virtual_text = true,
                underline = true,
                severity_sort = true,
                signs = {
                    text = {
                        [vim.diagnostic.severity.ERROR] = "",
                        [vim.diagnostic.severity.WARN] = "",
                        [vim.diagnostic.severity.INFO] = "",
                        [vim.diagnostic.severity.HINT] = "",
                    },
                },
            })

            -- 内联提示(C/C++ 的参数名等), <leader>li 可随时开关
            vim.lsp.inlay_hint.enable(true)

            -- clangd (使用系统 /usr/bin/clangd, 不通过 mason 安装) --
            vim.lsp.config("clangd", {
                cmd = {
                    "clangd",
                    "--clang-tidy",                     -- 启用 clang-tidy 检查
                    "--all-scopes-completion",          -- 补全包含全局作用域
                    "--completion-style=detailed",      -- 补全时显示详细签名
                    "--header-insertion=iwyu",          -- 自动插入头文件
                    "--header-insertion-decorators",
                    "--pch-storage=disk",               -- PCH 存磁盘, 省内存
                    "--background-index",               -- 后台建立索引
                    "--function-arg-placeholders=0",    -- 补全函数时不插入参数占位符
                    "--suggest-missing-includes",       -- 提示缺失的 include
                    "--cross-file-rename",              -- 跨文件重命名
                    "--query-driver=**",                -- 允许查询任意编译器(交叉编译时需要)
                    "--log=error",
                    "--j=12",                           -- 后台并行任务数
                    -- "--fallback-style=file",
                },
                init_options = {
                    -- 编译数据库位置; clangd 也会自动在项目根目录和 build/ 下查找
                    compilationDatabasePath = "./build",
                    -- 下面三个是 clangd 旧参数, 已被上面的命令行参数取代, 同时写会相互冲突:
                    -- usePlaceholders = true,            --> --function-arg-placeholders
                    -- completeUnimported = true,         --> --all-scopes-completion
                    -- clangdFileStatus = true,          --> 已废弃
                },
            })

            -- bash-language-server --
            vim.lsp.config("bashls", {
                filetypes = { "sh", "bash", "zsh" },    -- 官方默认 { "bash", "sh" }, 这里补上 zsh
                settings = {
                    bashIde = {
                        globPattern = "*@(.sh|.inc|.bash|.command|.zshrc|.zshprofile)",
                    },
                },
            })

            -- lua-language-server --
            vim.lsp.config("lua_ls", {
                settings = {
                    Lua = {
                        runtime = {
                            version = "LuaJIT",
                        },
                        workspace = {
                            library = {
                                vim.env.VIMRUNTIME,
                                "/usr/share/ura/runtime/",
                            },
                            -- checkThirdParty = false, -- 官方默认会弹窗询问第三方库, 需要时开启
                        },
                        telemetry = { enable = false },
                        diagnostics = { globals = { "vim", "ura", "Snacks" } },
                    },
                },
            })

            -- yaml-language-server --
            vim.lsp.config("yamlls", {
                settings = {
                    yaml = {
                        -- format.trailingComma 不是 yaml-language-server 的合法选项, 已移除
                        -- 官方默认值: yaml.format.enable = true
                        format = { enable = true },
                        -- schemas = {}    -- 见 :help lspconfig-all 里 yamlls 的说明
                    },
                },
            })

            -- css-language-server --
            vim.lsp.config("cssls", {
                settings = {
                    css = { lint = { unknownAtRules = "ignore" } },
                    scss = { lint = { unknownAtRules = "ignore" } },
                    less = { lint = { unknownAtRules = "ignore" } },
                },
            })

            -- taplo (toml) --
            vim.lsp.config("taplo", {
                -- 官方默认 { ".taplo.toml", "taplo.toml", ".git" }
                root_markers = { ".git", "*.toml" },
            })

            -- 启用(未在这里列出但被 mason 安装的 server 会由 automatic_enable 自动启用) --
            vim.lsp.enable({
                "bashls",
                "clangd",
                "cssls",
                "jsonls",
                "lua_ls",
                "neocmake",
                "ruff",
                "taplo",
                "ty",
                "yamlls",
            })

            -- 按键: nvim 0.12 已内建 grn(rename) / gra(code action) / grr(references) /
            --       gri(implementation) / grt(type definition) / gO(symbol) / K(hover) / ]d [d
            -- 这里只补 buffer 级别名和 clangd 专用操作
            vim.keymap.set("n", "<leader>li", function()
                local enabled = vim.lsp.inlay_hint.is_enabled()
                vim.lsp.inlay_hint.enable(not enabled)
                vim.notify("Inlay hints " .. (enabled and "disabled" or "enabled"))
            end, { desc = "Toggle inlay hints" })

            vim.api.nvim_create_autocmd("LspAttach", {
                callback = function(args)
                    local client = vim.lsp.get_client_by_id(args.data.client_id)
                    if not client then
                        return
                    end

                    vim.keymap.set("n", "gd", vim.lsp.buf.definition,
                        { buffer = args.buf, desc = "Go to definition" })

                    -- 只给 clangd 加: 在头文件里声明后, 一键在源文件生成函数定义
                    if client.name == "clangd" then
                        vim.keymap.set("n", "<leader>lc", function()
                            vim.lsp.buf.code_action({
                                filter = function(action)
                                    return action.title:find("Generate definition") ~= nil
                                end,
                                apply = true,
                            })
                        end, { buffer = args.buf, desc = "clangd: generate definition" })
                    end
                end,
            })
        end,
    },
}
