return {
    "lewis6991/gitsigns.nvim",
    event = { "BufReadPre", "BufNewFile" },
    opts = {
        -- 官方选项(全部为默认值): signs / signs_staged / signs_staged_enable / signcolumn /
        -- numhl / linehl / word_diff / watch_gitdir / auto_attach / attach_to_untracked /
        -- current_line_blame / current_line_blame_opts / current_line_blame_formatter /
        -- blame_formatter / sign_priority / update_debounce / status_formatter /
        -- max_file_length / preview_config / on_attach
        current_line_blame = false,     -- 需要时用 <leader>ghb 查看单行 blame
        word_diff = false,              -- :Gitsigns toggle_word_diff 可临时开启
        max_file_length = 40000,        -- 超过该行数不加载标记
        on_attach = function(bufnr)
            local gitsigns = require("gitsigns")

            local function map(mode, lhs, rhs, desc)
                vim.keymap.set(mode, lhs, rhs, { buffer = bufnr, desc = desc })
            end

            -- 跳转 (官方建议 ]c / [c, 这里用 ]h / [h 与 <leader>gh 分组保持一致)
            map("n", "]h", function()
                if vim.wo.diff then
                    vim.cmd.normal({ "]c", bang = true })
                else
                    gitsigns.nav_hunk("next")
                end
            end, "Next git hunk")
            map("n", "[h", function()
                if vim.wo.diff then
                    vim.cmd.normal({ "[c", bang = true })
                else
                    gitsigns.nav_hunk("prev")
                end
            end, "Previous git hunk")

            -- 暂存 / 撤销
            map("n", "<leader>ghs", gitsigns.stage_hunk, "Stage hunk")
            map("v", "<leader>ghs", function()
                gitsigns.stage_hunk({ vim.fn.line("."), vim.fn.line("v") })
            end, "Stage hunk")
            map("n", "<leader>ghr", gitsigns.reset_hunk, "Reset hunk")
            map("v", "<leader>ghr", function()
                gitsigns.reset_hunk({ vim.fn.line("."), vim.fn.line("v") })
            end, "Reset hunk")
            map("n", "<leader>ghS", gitsigns.stage_buffer, "Stage buffer")
            map("n", "<leader>ghR", gitsigns.reset_buffer, "Reset buffer")

            -- 查看
            map("n", "<leader>ghp", gitsigns.preview_hunk, "Preview hunk")
            map("n", "<leader>ghb", function()
                gitsigns.blame_line({ full = true })
            end, "Blame line")
            map("n", "<leader>ghd", gitsigns.diffthis, "Diff this")
            map("n", "<leader>ghD", function()
                gitsigns.diffthis("~")
            end, "Diff this against last commit")

            -- hunk 文本对象: dih / cih / vih
            map({ "o", "x" }, "ih", gitsigns.select_hunk, "Git hunk text object")
        end,
    },
}
