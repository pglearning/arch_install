return {
    "stevearc/conform.nvim",
    event = { "BufWritePre" },
    cmd = { "ConformInfo" },
    keys = {
        {
            "<leader>lf",
            function()
                require("conform").format({ async = true })
            end,
            mode = { "n", "v" },        -- visual 模式下自动格式化选中范围
            desc = "Format buffer / selection",
        },
    },
    opts = {
        -- 官方选项: formatters_by_ft / formatters / format_on_save / format_after_save /
        --           default_format_opts / notify_on_error / notify_no_formatters / log_level
        formatters_by_ft = {
            c = { "clang-format" },
            cpp = { "clang-format" },
            lua = { "stylua" },
            sh = { "shfmt" },
            bash = { "shfmt" },
            zsh = { "shfmt" },
            python = { "ruff_format" },
            json = { "prettier" },
            jsonc = { "prettier" },
            yaml = { "prettier" },
            markdown = { "prettier" },
            cmake = { "cmake_format" },
            toml = { "taplo" },
        },
        default_format_opts = {
            -- 没有配置 formatter 时回退到 LSP 格式化
            -- 可选: "never"(默认) | "fallback" | "prefer" | "first"
            lsp_format = "fallback",
        },
        -- 保存时自动格式化: 默认关闭, 需要时取消注释
        -- format_on_save = { timeout_ms = 500 },
    },
}
