return {
    "saghen/blink.cmp",
    dependencies = { "rafamadriz/friendly-snippets" },
    version = "1.*",
    event = "VeryLazy",
    -- build = "cargo build --release",     -- 默认使用官方预编译的 fuzzy 二进制
    opts = {
        -- 官方配置项: enabled / keymap / appearance / completion / signature / sources / fuzzy
        --            snippets / cmdline / term
        keymap = {
            -- 可选: "default" | "super-tab" | "enter" | "none"
            -- (cmdline / term 模式下额外支持 "cmdline" 和 "inherit")
            preset = "super-tab",
            -- 自定义按键会覆盖 preset, 例如:
            -- ["<C-y>"] = { "select_and_accept" },
            -- ["<C-e>"] = { "cancel", "fallback" },
        },
        appearance = {
            nerd_font_variant = "mono",     -- 官方默认值, "normal" 用于非 Mono 字体
        },
        completion = {
            documentation = {
                auto_show = true,           -- 官方默认 false(手动触发)
                -- auto_show_delay_ms = 500,
            },
            -- list = { max_items = 200, selection = { preselect = true, auto_insert = true } },
            -- menu = { enabled = true, min_width = 15, max_height = 10, border = nil, scrollbar = true },
            -- ghost_text = { enabled = false },   -- 行内灰色预览
            -- keyword = { range = "prefix" },
        },
        signature = {
            enabled = true,                 -- 官方默认 false; C/C++ 显示函数签名用 <C-k>
        },
        sources = {
            -- 官方默认 { "lsp", "path", "snippets", "buffer" }
            default = { "path", "snippets", "buffer", "lsp" },
            -- providers 里各来源的 score_offset: path=3, lsp=0, snippets=-1, buffer=-3
        },
        fuzzy = {
            implementation = "prefer_rust_with_warning",    -- 官方默认值
            -- 可选: "prefer_rust" | "rust" | "lua"
        },
        cmdline = {
            -- 该模式下官方默认 preset 是 "cmdline"(Tab 补全一段而不是整项)
            keymap = { preset = "super-tab" },
            completion = {
                menu = { auto_show = true },                -- 官方默认只在 cmdwin 中自动弹出
            },
            -- sources = { "buffer", "cmdline" },           -- 官方默认值
        },
    },
}
