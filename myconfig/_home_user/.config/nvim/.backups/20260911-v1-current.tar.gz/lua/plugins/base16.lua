return {
    "RRethy/base16-nvim",
    config = function()
        -- 颜色由 matugen 生成并在 lua/matugen.lua 中应用; 收到 SIGUSR1 时会自动重新应用
        -- (注意加载顺序: base16 在 catppuccin 之前加载, 所以启动时生效的是 catppuccin)
        local ok, matugen = pcall(require, "matugen")
        if ok then
            matugen.setup()
        end
    end,
}
