return {
    "nvim-neo-tree/neo-tree.nvim",
    branch = "v3.x",
    dependencies = {
        "nvim-lua/plenary.nvim",
        "nvim-tree/nvim-web-devicons",
        "MunifTanjim/nui.nvim",
    },
    lazy = false,               -- 官方建议, neo-tree 内部会自己按需加载
    keys = {
        {
            "<leader>e",
            function()
                require("neo-tree.command").execute({ toggle = true })
                -- require("fyler").toggle()
            end,
            desc = "Toggle file explorer",
        },
        -- 官方也支持命令方式: vim.keymap.set("n", "<leader>e", "<Cmd>Neotree<CR>")
    },
    opts = {
        -- 官方完整选项见 lua/neo-tree/defaults.lua, 或在 neo-tree 内按 ? 查看键位
        -- 常用顶层项: sources / close_if_last_window / enable_git_status / enable_diagnostics
        --             open_files_do_not_replace_types / sort_case_insensitive / default_component_configs
        --             default_source / use_default_mappings / event_handlers / commands
        close_if_last_window = false,       -- 官方默认值, 关掉最后一个窗口时不退出
        window = {
            position = "left",              -- 官方默认值: left|right|top|bottom|float|current
            width = 30,                     -- 官方默认 40
            -- height = 15,                 -- top/bottom 时的高度
            -- auto_expand_width = false,
        },
        filesystem = {
            -- 官方默认: hijack_netrw_behavior = "open_default"(用 nvim 打开目录时直接进入 neo-tree)
            follow_current_file = {
                enabled = true,             -- 光标切换文件时自动定位 (官方默认 false)
                leave_dirs_open = false,    -- 官方默认值
            },
            filtered_items = {
                visible = false,            -- 官方默认值, 在树里按 H 可临时显示
                hide_dotfiles = false,      -- 官方默认 true
                hide_gitignored = false,    -- 官方默认 true
                -- hide_by_name = { ".DS_Store", "thumbs.db" },   -- 官方默认值
                -- hide_by_pattern = {},
            },
        },
    },
}
